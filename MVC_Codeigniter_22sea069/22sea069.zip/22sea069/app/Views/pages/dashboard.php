<!-- Example Dashboard View: app/Views/pages/dashboard.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>
    <h1>Welcome to the Dashboard!</h1>
    <p>This is a placeholder for your user dashboard.</p>

    <!-- Logout Form -->
    <form action="/logout" method="post">
        <button type="submit">Logout</button>
    </form>
</body>
</html>
 