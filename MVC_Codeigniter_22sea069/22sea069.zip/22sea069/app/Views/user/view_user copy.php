<?= $this->extend('layouts/starter') ?>

<?= $this->section('title') ?>
User List
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container">
    <h2>User List</h2>
    <p>User List</p>
</div>
<?= $this->endSection() ?>
